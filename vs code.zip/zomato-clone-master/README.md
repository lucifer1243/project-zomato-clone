# zomato-clone
Minimalistic Zomato clone built using HTML, CSS and Bootstrap
This is an ongoing project and till now, it has successfully cloned the "Homepage" and "Order Food" pages of the Zomato website.
To view the project in browser you would want to open the file "home.html" .This opens the homepage.
You can also navigate to the "Order Food" at the top of the homepage.
